package com.cg.springaop.service;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LoginAdvice {

	@Before("execution(public * getLogin(* ))")           //point cut is @before       *means any method int void or any kind
	public void beforeLogin(){                             //beforelogin() is join point
		System.out.println("Call before Login..");
	}
	
	@After("execution(public void getLogin())")
	public void afterLogin(){
		System.out.println("Call after Login..");
	}
}
