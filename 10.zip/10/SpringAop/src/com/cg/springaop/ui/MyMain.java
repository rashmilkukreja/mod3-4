package com.cg.springaop.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext app= new ClassPathXmlApplicationContext("spring.xml");
		
		Login l = (Login) app.getBean("log");
		l.getLogin();
	}

}
