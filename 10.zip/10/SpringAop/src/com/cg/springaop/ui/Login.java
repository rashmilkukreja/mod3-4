package com.cg.springaop.ui;

public class Login 
{

	public int getLogin(){
		System.out.println("Welcome To AOP...");
		return 1;
	}
}
