package com.cg.springassone.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springassone.service.Employee;

public class MyMain {

	public static void main(String[] args) {
	

		ApplicationContext app = new ClassPathXmlApplicationContext("spring.xml");
		
		Employee myEmployee = (Employee) app.getBean("emp");
		myEmployee.showData();

	}

}
