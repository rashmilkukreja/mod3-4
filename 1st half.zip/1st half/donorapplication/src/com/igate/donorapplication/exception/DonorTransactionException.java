package com.igate.donorapplication.exception;

/**
 * Author		:	@author sn825940
 * Class Name	:	DonorTransactionException
 * Package		:	com.igate.donorapplication.exception
 * Date			:	Sep 12, 2014
 */

@SuppressWarnings("serial")
public class DonorTransactionException extends Exception{
	public DonorTransactionException(String message)
	{
		super(message);
	}
}
