

var custModule = angular.module("custModule", []);

custModule.run(function($rootScope){
	alert("In custModule")
	$rootScope.title='Customer Billing';
}
);
custModule.controller("custControl",
 
		function($scope){
	
	
	$scope.customer=[
	                 {'name':'aaaa','mobile':'9999'},
	                 {'name':'bbbb','mobile':'8888'},
	                 {'name':'cccc','mobile':'7777'}
	                 
	                 ];
	
}
);