
var billModule = angular.module("billModule",[]);                //imp to write before defining controller

billModule.run(function($rootScope){                              //acts as a constructor
	alert("In run method.");
	$rootScope.title="Bill Calculations";
	
});                                               

billModule.controller("productController", function($scope){
	$scope.product = {
			'cost': 0,
			'qty' : 1,
			'discount' : 0
	  };
	$scope.calcTotalBill = function(){
		return $scope.product.cost * $scope.product.qty;
	};
	
	$scope.calcDiscountBill = function(){
		return $scope.calcTotalBill() - $scope.calcTotalBill() * $scope.product.discount / 100;
	};
	
  }

);


billModule.controller("customerController", function($scope){
	$scope.customer = {
			'name': 'aaaa',
			'id' : 'a10002',
			'mobile' : '9999999999'
	}
}
		
);
