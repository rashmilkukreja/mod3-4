package com.cg.ass.service;

import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.ass.beans.Person;
import com.cg.ass.dao.IRegistrationDao;
import com.cg.ass.dao.RegistrationDaoImpl;
import com.cg.ass.exception.PersonException;




public class RegistrationService implements IRegistrationService
{

IRegistrationDao dao;
	
	public RegistrationService()
	{
	dao = new RegistrationDaoImpl() ;
	
	}
	
	
	@Override
	public void addPerson(Person person) throws PersonException, SQLException, NamingException {
		
		
			System.out.println(person);
			dao.addPerson(person);
			dao.show();
		
	}
   
}
