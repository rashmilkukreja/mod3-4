package com.cg.ass.service;

import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.ass.beans.Person;
import com.cg.ass.exception.PersonException;



public interface IRegistrationService 
{
	public void addPerson(Person person) throws PersonException, SQLException, NamingException;
	
}
