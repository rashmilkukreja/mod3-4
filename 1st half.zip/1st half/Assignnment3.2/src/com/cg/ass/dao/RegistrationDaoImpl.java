package com.cg.ass.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.ass.beans.Person;
import com.cg.ass.util.DBUtil;

public class RegistrationDaoImpl implements IRegistrationDao
{
	static Connection conn = null;
	static PreparedStatement pstm = null;

	@Override
	public void addPerson(Person person)
	{
		System.out.println("Welcome......");
		 try {
			conn = DBUtil.getConnection();
			 pstm = conn.prepareStatement("insert into registeredusers values(?,?,?,?,?,?)");
				
			 pstm.setString(1, person.getfName());
			 pstm.setString(2, person.getlName());
			 pstm.setString(3, person.getPassword());
			 pstm.setString(4, person.getGender());
			 pstm.setString(5, person.getSkill());
			 pstm.setString(6, person.getCity());
			 
			 pstm.executeUpdate();
			 
		} catch (SQLException | NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void show()
	{
		
		
	}

}
