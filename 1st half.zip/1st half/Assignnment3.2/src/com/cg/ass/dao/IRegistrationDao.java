package com.cg.ass.dao;

import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.ass.beans.Person;

public interface IRegistrationDao
{
	public void addPerson(Person person);
	public void show();
}
