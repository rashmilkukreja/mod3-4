package com.cg.ass.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ass.beans.Person;
import com.cg.ass.exception.PersonException;
import com.cg.ass.service.IRegistrationService;
import com.cg.ass.service.RegistrationService;



@WebServlet("*.mvc")
public class RegistrationController extends HttpServlet
{
	
	 IRegistrationService service;
	
    @Override
    public void init() throws ServletException 
    {
    	service = new RegistrationService();
    }
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Controller is invoked"+request.getServletPath());
		String action = request.getServletPath();
		
		switch (action)
		{
		case "/AddPersonForm.mvc":
			System.out.println("Add Form");
			RequestDispatcher dispatcher = request.getRequestDispatcher("AddPersonForm.jsp");
			dispatcher.forward(request, response);
			
			break;
			
		case "/AddPerson.mvc":
			String fName = request.getParameter("addFName");
			String lName = request.getParameter("addLName");
			String password = request.getParameter("addPassword");
			String gender = request.getParameter("addGender");
			String skill = request.getParameter("addSkill");
			String city = request.getParameter("addCity");
			
			Person person = new Person();
			
			person.setfName(fName);
			person.setlName(lName);
			person.setPassword(password);
			person.setGender(gender);
			person.setSkill(skill);
			person.setCity(city);
			
			PrintWriter out=response.getWriter(); 
			try {
				service.addPerson(person);
				out.println("Data Insserted");
				response.sendRedirect("index.html");
			} 
			catch (PersonException | SQLException | NamingException e) {
				
				e.printStackTrace();
				
			}
			
			break;
			
		case "/ViewAll.mvc":
			System.out.println("view All");
			break;
		
		default:
			break;
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
