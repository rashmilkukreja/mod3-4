package com.cg.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.exception.EMSException;
import com.cg.model.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.IEmployeeService;


@WebServlet("/employees")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public EmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		//Create instance of Service
		System.out.println(action);
		IEmployeeService service = new EmployeeService();
		
		if(action==null){
			action = "";
		}
		
		switch (action) {
		case "add":
			System.out.println("came here");
          String dob = request.getParameter("dob");
			
			
			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
	        Date date=null;
			try {
				date = format.parse(dob);
			} catch (ParseException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
	        java.sql.Date actDate = new java.sql.Date(date.getTime());
			 
			 
			 Employee e1 = new Employee();
			    e1.setId(request.getParameter("id"));
				e1.setName(request.getParameter("name"));
				e1.setDob(actDate);
			    e1.setQualification(request.getParameter("qualification"));
				e1.setDepartment(request.getParameter("department"));
				
				//save using service
				
			try {
				service.add(e1);
			} catch (EMSException exception) {
				// TODO Auto-generated catch block
				exception.printStackTrace();
			}
				
				//store error/success message in SESSION
				request.getSession().setAttribute("emp", e1);
				
				RequestDispatcher view2 = request.getRequestDispatcher("employees?action=show");
				view2.forward(request, response);
			
			break;

		case "show":
		case "":
			try{
				
				List<Employee> emp=service.show();
				
				request.getSession().setAttribute("emplist",emp);
				System.out.println(emp);
				request.getSession().getAttribute("show.jsp");
			}catch(EMSException ex)
			{
				request.getSession().setAttribute("error",ex.getMessage());
			}
			
			
			  RequestDispatcher view4 = request.getRequestDispatcher("show.jsp");
			  
				view4.forward(request, response);
				break;
		
	}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
