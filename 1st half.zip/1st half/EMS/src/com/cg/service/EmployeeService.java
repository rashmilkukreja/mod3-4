package com.cg.service;

import java.util.List;

import com.cg.dao.EmployeeDao;
import com.cg.dao.IEmployeeDao;
import com.cg.exception.EMSException;
import com.cg.model.Employee;

public class EmployeeService implements IEmployeeService
{
	private IEmployeeDao dao = null;

	public EmployeeService() {
		dao = new EmployeeDao();
	}
	

	@Override
	public void add(Employee e) throws EMSException {
		
		dao.add(e);
		
	}

	

	@Override
	public List<Employee> show() throws EMSException {
		// TODO Auto-generated method stub
		return dao.show();
	}
	

}
