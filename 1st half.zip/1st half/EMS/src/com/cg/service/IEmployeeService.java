package com.cg.service;

import java.util.List;

import com.cg.exception.EMSException;
import com.cg.model.Employee;

public interface IEmployeeService 
{
	void add(Employee e) throws EMSException;
	List<Employee> show() throws EMSException;
	

}
