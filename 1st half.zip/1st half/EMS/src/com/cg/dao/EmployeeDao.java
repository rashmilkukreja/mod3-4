package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.naming.NamingException;

import com.cg.exception.EMSException;
import com.cg.model.Employee;
import com.cg.util.Dbutil;

public class EmployeeDao implements IEmployeeDao
{
	private static final String INSERT_QUERY
	="INSERT into emp(id,name,dob,qualification,department) "+  
		"values(?,?,?,?,?)";

	private static final String GET_ALL_QUERY
	="select * from emp";
	

	@Override
	public void add(Employee e) throws EMSException {
		try{
			Connection con = Dbutil.obtainConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);
			ps.setString(1, e.getId());
			ps.setString(2,e.getName());
			ps.setDate(3, e.getDob());
			ps.setString(4,e.getDepartment());
			ps.setString(5,e.getQualification());
			
			ps.executeUpdate();
			con.close();
		}catch(NamingException | SQLException e1){
			throw new EMSException("Unable to save, "+e1.getMessage());
		}
		
		
	}

	@Override
	public List<Employee> show() throws EMSException {
		try{
			Connection con = Dbutil.obtainConnection();
			PreparedStatement ps = con.prepareStatement(GET_ALL_QUERY);
			ResultSet rs = ps.executeQuery();
			//Create EMPTY list
			List<Employee> emps = new LinkedList<>();
			//Get ONE record at a time
			while(rs.next()){
				Employee e = new Employee();
				//Store ALL values into Employee Object
				//"e" is now D.T.O.
				e.setId(rs.getString(1));
				e.setName(rs.getString(2));
				e.setDob(rs.getDate(3));
			    e.setQualification(rs.getString(4));
				e.setDepartment(rs.getString(5));
				
				//Add DTO into LIST
				emps.add(e);
			}
			return emps;
			
			
			
		}catch(NamingException | SQLException ex){
			throw new EMSException("Unable to fetch records, "+ex.getMessage());
		}
		
	}
	

}
