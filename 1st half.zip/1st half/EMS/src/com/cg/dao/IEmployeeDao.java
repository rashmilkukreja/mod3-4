package com.cg.dao;

import java.util.List;

import com.cg.exception.EMSException;
import com.cg.model.Employee;

public interface IEmployeeDao 
{
	void add(Employee e) throws EMSException;

	List<Employee> show() throws EMSException;


}
