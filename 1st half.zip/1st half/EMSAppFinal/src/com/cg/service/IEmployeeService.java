package com.cg.service;

import java.util.List;

import com.cg.exception.EMSException;
import com.cg.models.Employee;

public interface IEmployeeService {

	int add(Employee e) throws EMSException;
	
	List<Employee> getAll() throws EMSException;
	
	void update(Employee e)throws EMSException;
	
	Employee search(int empid)throws EMSException;
}