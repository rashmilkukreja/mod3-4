package com.cg.exception;

public class EMSException extends Exception
{

	public EMSException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
  
}
