package com.capgemini.web.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(
		   name="/RegisterForm",
           urlPatterns={"RegisterForm"},
           initParams={
           @WebInitParam(name="countries", value="India, USA, Australia")
           })


public class RegisterForm extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	
    	ServletConfig config = getServletConfig();
        String countries = config.getInitParameter("countries");
    	
    	ServletContext context = getServletContext();
    	String company = context.getInitParameter("company");
    	
    	
        Object obj = request.getAttribute("errMsg");           //we get object of errorpage 
    	ArrayList<String> errMsgs = null;  
    	
    	
    	
        response.setContentType("text/html");
    	
    	PrintWriter out = response.getWriter();
    	
    	out.println("<html>");
    	out.println("<body>");
    	
    	if(company != null && company.isEmpty() == false)
    	{
    		out.println("<h1>"+ company +"</h1>");
    	}
    	
    	
    	if( obj != null && obj instanceof ArrayList )
    	{
    		errMsgs = (ArrayList<String>) obj;
    		
    		out.println("<ul>");
    		
    		for(int index = 0; index < errMsgs.size(); index++ )
    		{
    			out.println("<Li> "+ errMsgs.get(index) +" </Li>");
    		}
    		
    		out.println("</ul>");
    	}
    	
    	
    	
    	out.println("<form action='ProcessRegisterForm' method='post'>");

    	out.println("<table>");
    	
    	out.println(" <tr>");
    	out.println(" <td>Name</td>");
    	out.println(" <td><input type='text' name='name'></td>");
    	out.println(" </tr>");
    	
    	out.println(" <tr>");
    	out.println(" <td>Mobile</td>");
    	out.println(" <td><input type='text' name='mobile'></td>");
    	out.println(" </tr>");
    	
    	out.println(" <tr>");
    	out.println(" <td>Email</td>");
    	out.println(" <td><input type='text' name='email'></td>");
    	out.println(" </tr>");
    	
    	out.println(" <tr>");
    	out.println(" <td>Country</td>");
    	out.println(" <td>");
    	out.println(" <select name='country'>");
    	
    	if(countries != null && countries.isEmpty() == false)
    	{
    		String[] countryNames = countries.split(", ");
    		
    		for(int index = 0; index < countryNames.length; index++ )
    		{
    			out.println("<option value = '"+countryNames[index]+"'>"+countryNames[index]+"</option>"); 
    		}
    	}
    	
    	
    	
    	out.println(" </select>");
    	out.println(" </td>");
    	out.println(" </tr>");
    	
    	out.println(" <tr>");
    	out.println(" <td><input type='submit' name='Register'></td>");
    	out.println(" <td><input type='reset' name='clear'></td>");
    	out.println(" </tr>");
    	       


    	out.println(" </table>");

    	out.println(" </form>");
    	
    	out.println(" </body>");
    	out.println(" </html>");
	}
}
