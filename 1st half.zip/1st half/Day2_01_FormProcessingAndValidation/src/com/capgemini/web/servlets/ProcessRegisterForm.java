package com.capgemini.web.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ProcessRegisterForm")

public class ProcessRegisterForm extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	//read the form
    	String name= request.getParameter("name");
    	String mobile= request.getParameter("mobile");
    	String email= request.getParameter("email");
    	String country= request.getParameter("country");
    	
    	getServletContext().setAttribute("username", name);
    	
    	ArrayList<String> fieldErrorMessage = new ArrayList<>();
    	
    	//form validation
    	
    	if( name == null || name.isEmpty() )
    	{
    		fieldErrorMessage.add("Name cannot be empty");
    	}
    	
    	if( mobile == null || mobile.isEmpty() )
    	{
    		fieldErrorMessage.add("Mobile cannot be empty");
    	}
    	
    	if( email == null || email.isEmpty() )
    	{
    		fieldErrorMessage.add("email cannot be empty");
    	}
    	
    	if( country == null || country.isEmpty() )
    	{
    		fieldErrorMessage.add("country cannot be empty");
    	}
    	
    	
    	RequestDispatcher rd = null;
    	
    	if( fieldErrorMessage.isEmpty() )
    	{
    		//action when validation is success
    		rd = request.getRequestDispatcher("SuccessPage");
    	}
    	else
    	{
    		//action when validation is failure
    		request.setAttribute("errMsg", fieldErrorMessage);          //add to another servlet
    		rd = request.getRequestDispatcher("RegisterForm");
    	}
    	
    	rd.forward(request, response);
	}
	
}
