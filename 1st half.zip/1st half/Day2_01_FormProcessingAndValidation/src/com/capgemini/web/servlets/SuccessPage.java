package com.capgemini.web.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/SuccessPage")
public class SuccessPage extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	
    	ServletConfig config = getServletConfig();
        String countries = config.getInitParameter("countries");
    	
    	
    	ServletContext context = getServletContext();
    	String company = context.getInitParameter("company");
    	
    	//warning that sending text data to browser
    	//MIME TYPES
    	response.setContentType("text/html");
    	
    	PrintWriter out = response.getWriter();
    	
    	out.println("<html>");
    	out.println("<body>");
    	
    	if(company != null && company.isEmpty() == false)
    	{
    		out.println("<h1>"+ company +"</h1>");
    	}
    	
    	out.println("Countries:");
    	if(countries != null && countries.isEmpty() == false)
    	{
    		String[] countryNames = countries.split(", ");
    		
    		for(int index = 0; index < countryNames.length; index++ )
    		{
    			out.println("<option value = '"+countryNames[index]+"'>"+countryNames[index]+"</option>"); 
    		}
    	}
    	
    	String name = (String)getServletContext().getAttribute("username");
    	
    	
    	out.println("<p>Hello" +name +" your Form Submitted Successfully</p>");
    	out.println("</body>");
    	out.println("</html>");
    	
	}
}
