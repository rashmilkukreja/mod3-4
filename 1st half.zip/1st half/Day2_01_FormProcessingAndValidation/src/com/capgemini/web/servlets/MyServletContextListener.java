package com.capgemini.web.servlets;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class MyServletContextListener implements ServletContextListener 

{
	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		
	arg0.getServletContext().setInitParameter("company", "capgemini");
		
	}

    @Override
    public void contextDestroyed(ServletContextEvent arg0) {
	
	
		
	}

	
	
}
