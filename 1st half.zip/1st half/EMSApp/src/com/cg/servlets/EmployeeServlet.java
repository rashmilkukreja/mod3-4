package com.cg.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.exception.EMSException;
import com.cg.models.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.IEmployeeService;


@WebServlet("/employees")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public EmployeeServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		
		//create instance of service
		IEmployeeService service = new EmployeeService();
		
		switch (action) {
		case "list":    // show all
			
			
			try{
			//code to list employees from service
			List<Employee> emps = service.getAll();
			//add list into SESSION
			request.getSession().setAttribute("emplist", emps);
			//forward request to list.jsp
			}catch(EMSException ex){
				request.getSession().setAttribute("error", ex.getMessage());
			}
			//now forward to success.jsp
			RequestDispatcher view = request.getRequestDispatcher("list.jsp");
			view.forward(request, response);
			return;

		
		case "add":
			//code to add employee
			Employee e = new Employee();
			e.setName(request.getParameter("name"));
			e.setDesignation(request.getParameter("designation"));
			e.setGender(request.getParameter("gender"));
			e.setEmail(request.getParameter("email"));
			e.setPhone(request.getParameter("phone"));
			
			//save using service
			try{
				int id = service.add(e);
				e.setEmpId(id);
			}catch(EMSException ex){
				request.getSession().setAttribute("error", ex.getMessage());
			}
			//store errors/success message in session
			request.getSession().setAttribute("emp", e);
			
			//forward request to "success.jsp"
			RequestDispatcher view2 = request.getRequestDispatcher("success.jsp");
			view2.forward(request, response);
			return ;
		
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
