package com.cg.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import javax.naming.NamingException;

import com.cg.exception.EMSException;
import com.cg.models.Employee;
import com.cg.util.DbUtil;

public class EmployeeDAO implements IEmployeeDAO
{
	private static final String INSERT_QUERY ="INSERT into emp2(empid,ename,gender,designation,phone,email)"+" values(emp_seq2.nextval, ?,?,?,?,?)";
	private static final String GET_ALL_QUERY = "select empid,ename,gender,designation,phone,email from emp2";
	
	@Override
	public int add(Employee e) throws EMSException {
		try{
			Connection con = DbUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);
			ps.setString(1, e.getName());
			ps.setString(2, e.getGender());
			ps.setString(3, e.getDesignation());
			ps.setString(4, e.getPhone());
			ps.setString(5, e.getEmail());
			ps.executeUpdate();
			
			int id = 0;
			//Get generated Primary key
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select emp_seq2.currval from dual");
			
			if(rs.next()){
				
				id = rs.getInt(1);
				System.out.println("SEQ value "+id);
			}
			
			con.close();
			return id;
			
		}catch(NamingException | SQLException ex)
		{
			throw new EMSException("Unable to save.." +ex.getMessage());
		}
		
	}

	@Override
	public List<Employee> getAll() throws EMSException{
		try{
			Connection con = DbUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(GET_ALL_QUERY);
			ResultSet rs = ps.executeQuery();
			
			//create empty list
			List<Employee> emps = new LinkedList<>();
			
			//Get one record at a time
			while(rs.next()) {
				Employee e = new Employee();
				
				//Store all values into Employee object
				//"e" is now DTO
				e.setEmpId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setGender(rs.getString(3));
				e.setDesignation(rs.getString(4));
				e.setPhone(rs.getString(5));
				e.setEmail(rs.getString(6));
				//add DTO into list
				emps.add(e);
			}
			con.close();
	
	//return list
			return emps;
		}catch(NamingException | SQLException ex)
		{
			throw new EMSException("Unable to save.." +ex.getMessage());
		}
		
	}

//	@Override
//	public void update(Employee e)  {
//		
//		
//	}
	}


